package loderunner.services;

public enum Status {
	Playing, Win, Loss
}
