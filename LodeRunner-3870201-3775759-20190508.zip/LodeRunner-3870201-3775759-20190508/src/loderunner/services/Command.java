package loderunner.services;

public enum Command {
	Right,Left,Up,Down,Neutral,DigL,DigR
}
