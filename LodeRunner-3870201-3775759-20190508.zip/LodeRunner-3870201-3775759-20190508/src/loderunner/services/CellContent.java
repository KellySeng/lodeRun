package loderunner.services;

public interface CellContent {

}
