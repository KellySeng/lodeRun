package loderunner.services;

public enum Cell {
	EMP, //empty
	PLT, // plateforme
 	HOL, // trou
	LAD, //echelle
	HDR, // handrail
	MTL //metal
}
