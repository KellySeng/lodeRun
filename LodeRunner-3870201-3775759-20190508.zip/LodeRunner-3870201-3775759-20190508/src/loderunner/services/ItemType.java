package loderunner.services;

public enum ItemType implements CellContent {
	Treasure
}
