package loderunner.services;

public enum Move {
	Right,Left,Up,Down,Neutral
}
